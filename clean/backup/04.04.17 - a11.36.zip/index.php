<?php
include "page/home.html";
?>