<?php 

$conn = mysql_connect("localhost", "root", "", "") or die("Failed to connect");
mysqli_select_db("databa39_library")

?>