<!DOCTYPE html>
<html>
	<head>
		<!--Page title in tab-->
		<title>Display All</title>
		<!--Link to CSS page-->
		<link rel="stylesheet" href="library.css">
		<!--Embedded code for Font Awesome icons-->
		<script src="https://use.fontawesome.com/4f7fcc0d3d.js"></script>
	</head>
	<body>
		<div class="container">
			<!--Header section-->
			<header>
				<!--Larger header section-->
				<div class="main">
					<h1>University of Houston</h1>
					<h3>Libraries</h3>
				</div>
				<!--Bar containing Home button, Login/Logout-->
				<div class="subhead">
               		<a href="http://www.databaseteam12.x10host.com" style="margin-right: 5px;">Home</a>
					<a href="http://www.databaseteam12.x10host.com/login.php" style="margin-right: 5px;">Register</a>
					<a href="http://www.databaseteam12.x10host.com/logout.php">Login</a>
				</div>
			</header>
			<!--Main section-->
			<!--Navigation sidebar-->
			<nav>
            	<ul>
					<li>
						<div class="nav-drop">
                			<button class="drop">Search Media</button>
							<!--Dropdown contents-->
                			<div class="nav-drop-content">
                  				<a href="http://www.databaseteam12.x10host.com/displayAll.php">Display All</a>
                  				<a href="http://www.databaseteam12.x10host.com/displayAllBooks.php">Display All Books</a>
								<a href="http://www.databaseteam12.x10host.com/displayAllCassettes.php">Display All Cassettes</a>
								<a href="http://www.databaseteam12.x10host.com/displayAllCds.php">Display All CDs</a>
								<a href="http://www.databaseteam12.x10host.com/displayAllDvds.php">Display All DVDs</a>
								<a href="http://www.databaseteam12.x10host.com/displayAllVhs.php">Display All VHS</a>
                			</div>
              			</div>
					</li>
                	<li>
              			<div class="nav-drop">
							<button class="drop">Laptop Rentals</button>
							<!--Dropdown contents-->
							<div class="nav-drop-content">
								<a href="http://www.databaseteam12.x10host.com/displayAllLaptops.php">Display All Laptops</a>
							</div>
						</div>
                    </li>
                	<li>
              			<div class="nav-drop">
							<button class="drop">Room Reserve</button>
							<!--Dropdown contents-->
							<div class="nav-drop-content">
								<a href="http://www.databaseteam12.x10host.com/displayAllRooms.php">Display All Rooms</a>
							</div>
						</div>
                    </li>
               	</ul>
			</nav>
			<!--Main body-->
			<main>
				<div class="inner">
					<i>Displaying All Media Results:</i><br>
					<!--Content-->
					<?php
					$servername = "162.253.224.12";
					$username = "databa39_user";
					$password = "databa39team12";
					$dbname = "databa39_library";

					// Create connection
					$conn = new mysqli($servername, $username, $password, $dbname);
					// Check connection
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					} 

					$sql = "CALL display_all_media();";
					$result = $conn->query($sql);
					
					if ($result->num_rows > 0) {
						// Output data of each row
						while($row = $result->fetch_assoc()) {
							echo "<br><h2>".$row["title"]."</h2>"
							.$row["first_name"]." ".$row["last_name"]." "
							.$row["published_date"]."<br>".$row["publisher"].".<br><br>";
							?>
							<div class="detail_label">More Details</div>
								<div class='details'>
							<?php
							echo "<b>Title:</b> ".$row["title"]."<br>
									<b>Author:</b> ".$row["first_name"]." ".$row["last_name"]."<br>
									<b>Genre:</b> ".$row["genre"]."<br>
									<b>Audience:</b> ".$row["audience"]."<br>
									<b>Publisher:</b> ".$row["publisher"]."<br>
									<b>Creation Date:</b> ".$row["published_date"]."<br>
									<b>Language:</b> ".$row["language"];
							?>
								</div>
							<?php
							if ($row["is_available"] == "available") {
								echo "<p><i class='fa fa-check-circle' aria-hidden='true' 
									style='color: #57BC57'></i> Copy #".$row["copy_num"]." is 
									<b>available</b>. 
									<button>Hold</button> <button>Reserve</button></p>";
							}
							else {
								echo "<p><i class='fa fa-times-circle' aria-hidden='true'
									style='color: #D25252'></i> Copy #".$row["copy_num"]." is 
									<b>".$row["is_available"]."</b>.</p>";
							}
						}
					} else {
						echo "0 results";
					}
					$conn->close();
					?>
				</div>
			</main>
			<!--Footer section-->
			<footer>
				&copy; Spring 2017 COSC 3380 Team 12
				<br><br>
				4333 University Drive
				<br>
				Houston, TX 77204-2000
			</footer>
		</div>
	</body>
</html>