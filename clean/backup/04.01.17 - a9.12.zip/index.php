<!DOCTYPE html>
<html>
	<head>
		<!--Page title in tab-->
		<title>Home</title>
		<!--Link to CSS page-->
		<link rel="stylesheet" href="library.css">
	</head>
	<body>
		<div class="container">
			<!--Header section-->
			<header>
				<!--Larger header section-->
				<div class="main">
					<h1>University of Houston</h1>
					<h3>Libraries</h3>
				</div>
				<!--Bar containing Home button, Login/Logout-->
				<div class="subhead">
               		<form action="" style="width: 62px; float: left; margin-left: 20px;">
						<a href="http://www.databaseteam12.x10host.com" ><button>Home</button></a>
					</form>
					<form action="" style="width: 91px; float: right;">
						<a href="http://www.databaseteam12.x10host.com/login.php" ><button>Register</button></a>
					</form>
					<form action="" style="width: 64px; float: right;">
						<a href="http://www.databaseteam12.x10host.com/logout.php" ><button>Login</button></a>
					</form>
				</div>
			</header>
			<!--Main section-->
			<!--Navigation sidebar-->
			<nav>
            	<ul>
					<li>
						<div class="nav-drop">
                			<button class="drop">Search Media</button>
							<!--Dropdown contents-->
                			<div class="nav-drop-content">
                  				<a href="http://www.databaseteam12.x10host.com/displayAll.php">Display All</a>
                  				<a href="http://www.databaseteam12.x10host.com/displayAllBooks.php">Display All Books</a>
								<a href="http://www.databaseteam12.x10host.com/displayAllCassettes.php">Display All Cassettes</a>
								<a href="http://www.databaseteam12.x10host.com/displayAllCds.php">Display All CDs</a>
								<a href="http://www.databaseteam12.x10host.com/displayAllDvds.php">Display All DVDs</a>
								<a href="http://www.databaseteam12.x10host.com/displayAllVhs.php">Display All VHS</a>
                			</div>
              			</div>
					</li>
                	<li>
              			<div class="nav-drop">
							<button class="drop">Laptop Rentals</button>
							<!--Dropdown contents-->
							<div class="nav-drop-content">
								<a href="http://www.databaseteam12.x10host.com/displayAllLaptops.php">Display All Laptops</a>
							</div>
						</div>
                    </li>
                	<li>
              			<div class="nav-drop">
							<button class="drop">Room Reserve</button>
							<!--Dropdown contents-->
							<div class="nav-drop-content">
								<a href="http://www.databaseteam12.x10host.com/displayAllRooms.php">Display All Rooms</a>
							</div>
						</div>
                    </li>
               	</ul>
			</nav>
			<!--Main body-->
			<main>
				<div class="inner">
					<!--Header of content-->
					<h2>Welcome!</h2>
					<!--Content-->
					<p>This is Team 12's Database project. Please login if you have an account, or register if you're new here.</p>
					<p>When logged in, the menu will display on the right. Use it to search for media in the library's collection.</p>
				</div>
			</main>
			<!--Footer section-->
			<footer>
				&copy; Spring 2017 COSC 3380 Team 12
				<br><br>
				4333 University Drive
				<br>
				Houston, TX 77204-2000
			</footer>
		</div>
	</body>
</html>